# -*- coding: utf-8 -*-
"""
Created on Sat Jan 11 16:59:36 2020

@author: liamo
"""
from Protein import Protein   
from DataBase import DataBase
from StackQueue import Queue #FIFO


def menu():
    while True:
        print("""
        ======== Funções ============
        0. Sair
        1.Protein.findInDB
        2.DataBase
        3.DataBase
        4.DataBase
        5.DataBase
        6.DataBase
        """)
        op = input("Escolha uma opção: ")
        if op == "1":
            "test_agua()"
        elif op == "2":
            "test_agua_coluna()"
            #history.push()
        elif op == "3":
            "test_agua_linha()"
            #history.push()
        elif op == "4":
            "test_ajuda()"
            #history.push()
        elif op == "5":
            "test_deteta()"
            #history.push()
        elif op == "6":
            pass
            #history.push()
        elif op == "0":
            with open("history.txt","a") as file:
                while history.isempty() is False:
                    file.write(history.dequeue())
            break
        else:
            print("\n Opcao nao valida.")
    print("\n Adeus")
    
if __name__ == "__main__":
    #menu()