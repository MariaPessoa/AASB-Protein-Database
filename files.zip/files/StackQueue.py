# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 16:16:49 2019

@author: liamo
"""


class Stack:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return self.items == []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def top(self):
        return self.items[len(self.items)-1]

    def size(self):
        return len(self.items)


class Queue:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def enqueue(self, item):
        self.items.insert(0,item)

    def front(self):
        return self.items[len(self.items)-1]

    def dequeue(self):
        return self.items.pop()

    def size(self):
        return len(self.items)


class Queue2:
    def __init__(self):
        self.s1 = Stack()
        self.s2 = Stack()
        
    def is_empty(self):
        return self.s1.is_empty()

    def enqueue(self,item):
        self.s1.push(item)

    def front(self):
        while self.s1.items:
            self.s2.push(self.s1.pop())
        valor = self.s2.top()
        while self.s2.items:
            self.s1.push(self.s2.pop())
        return valor
    
    def dequeue(self):
        while self.s1.items:
            self.s2.push(self.s1.pop())
        valor = self.s2.pop()
        while self.s2.items:
            self.s1.push(self.s2.pop())
        return valor

    def size(self):
        return len(self.s1.items)


class Stack2:
    def __init__(self):
        self.q1 = Queue()
        self.q2 = Queue()

    def is_empty(self):
        return self.q1.is_empty()

    def push(self, item):
        self.q1.enqueue(item)

    def pop(self):
        i = 0
        while self.q1.items:
            self.q2.enqueue(self.q1.dequeue())
            i += 1
        while i > 1:
            self.q1.enqueue(self.q2.dequeue())
            i -= 1
        valor = self.q2.dequeue()
        self.q2.dequeue(valor)
        return valor

    def top(self):
        i = 0
        while self.q1.items:
            self.q2.enqueue(self.q1.dequeue())
            i += 1
        while i > 1:
            self.q1.enqueue(self.q2.dequeue())
            i -= 1
        valor = self.q2.dequeue()
        self.q1.enqueue(valor)
        return valor
    
    def size(self):
        return len(self.q1.items)


if __name__ == "__main__":
    q = Queue2()
    for i in range(1,4):
        q.enqueue(i)
    print("front:",q.front())
    print("dequeue:",q.dequeue())
    print("dequeue:",q.dequeue())
    print("dequeue:",q.dequeue())
