    
from BinaryTree import BinaryTree
#from MatrixNum import MatrixNum

class ClustHier:

    def __init__(self, matdists):
        self.matdists = matdists
        
    def distance (self, tree1, tree2):
        c1 = tree1.getCluster() #nº seqs de cada tree
        c2 = tree2.getCluster()        
        sd= 0.0        
        for i in range(len(c1)):                
            for j in range(len(c2)):                    
                sd+= self.matdists.getValue(c1[i], c2[j]) #buscar vals a mat       
        return sd/(len(c1)*len(c2)) #distancia media
    
    def executeClustering(self):
        trees = []
        tableDist = self.matdists.copy()
        for i in range(self.matdists.numRows()): #1 arvore por seq
            t = BinaryTree(i)
            trees.append(t) # adds leaves to the list
        for k in range(self.matdists.numRows(), 1, -1):
            # choose minimum value from matrix not in diagonal
            mins = tableDist.minDistIndexes()
            i = mins[0]
            j = mins[1]
            n = BinaryTree(-1, tableDist.getValue(i, j)/2.0, trees[i], trees[j])
            if k>2:
                trees.pop(i)
                trees.pop(j)
                tableDist.removeRow(i)
                tableDist.removeRow(j)
                tableDist.removeCol(i)
                tableDist.removeCol(j)
                dists = []
                for x in range(len(trees)):
                    dists.append(self.distance(n, trees[x]))
                tableDist.addRow(dists)
                cdists = []
                for y in range(len(dists)):
                    cdists.append(dists[y])
                cdists.append(0.0)
                tableDist.addCol(cdists)
                trees.append(n)
            else: return n
            #tableDist.printmat()
