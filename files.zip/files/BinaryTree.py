
import sys

class BinaryTree:

    def __init__(self, val, dist=0, left = None, right = None):
        self.value = val
        self.distance = dist
        self.left = left
        self.right = right
        
    def getCluster(self):
        res = []
        if self.value >= 0:
            res.append(self.value)
        else:
            if (self.left!= None):
                res.extend(self.left.getCluster())
            if (self.right!= None): 
                res.extend(self.right.getCluster())
        return res
    
    def printtree(self):
        self.printtreerec(0, "Root")
    
    def printtreerec (self, level, side):
        for i in range(level): sys.stdout.write("\t")
        al = self.getCluster();
        sys.stdout.write(side + ":" + str(al)+ " Dist.: " + str(self.distance) + "\n")
        if self.value < 0:
            if (self.left != None): 
                self.left.printtreerec(level+1, "Left")
            else: 
                sys.stdout.write("Null")
            if (self.right != None): 
                self.right.printtreerec(level+1, "Right")
            else: 
                sys.stdout.write("Null\n")
